<?php
session_start();

// Connect to the database
$conn = mysqli_connect("localhost", "root", "", "sysarc");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$userId = $_SESSION['Idno']; 
$sql = "SELECT last_name, first_name, session FROM user WHERE Idno = $userId";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $lastName = $row['last_name'];
    $firstName = $row['first_name'];
    $session = $row['session'];
} else {
    header("Location: login.php"); 
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title>Student Dashboard</title>

    <script>
        swal({
            title: "You have logged in successfully!",
            text: "Click the button to continue!",
            icon: "success",
        });
    </script>
<style>


    ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }

li {
float: none;
display: inline-block;
}

li a {
display: inline-block;
color: white;
text-align: left;
padding: 14px 16px;
text-decoration: none;
}

li a:hover {
background-color: #111;
}

.search-button{
    width: 100%;
    height: 50px;
    align-content: center;
}
h1 {
    text-align: center;
    padding-top:100px;
    
}


</style>
</head>
<body>
    <ul>
        <li><a href="Student.php">Student Dashboard</a></li>
        <div class="right" style="float: right;">
            <li><a href="edit-profile.php">Edit Profile</a></li>
            <li><a href="student-history.php">History</a></li>
            <li><a href="session.php">Session</a></li>
            <li><a href="announcement.php">Announcement</a></li>
            <li><a href="Activity2.php">Log Out</a></li>
            <li>&nbsp;&nbsp;</li>
        </div>    
    </ul>
</div>
</div>
    <div>
        <h1><?php echo $lastName?>, <?php echo $firstName?> Remaining Session: <?php echo $session; ?></h1>
    </div>
</body>
</html>