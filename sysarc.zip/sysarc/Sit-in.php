<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sit-in</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Include SweetAlert JS -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: none;
            display: inline-block;
        }

        li a {
            display: inline-block;
            color: white;
            text-align: left;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }

        .search-container {
            text-align: center;
            margin-top: 50px;
        }

        .search-container input[type=text] {
            width: 70%;
            padding: 12px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
        }

        .search-container button {
            width: 20%;
            padding: 12px;
            margin: 8px 0;
            box-sizing: border-box;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }

        .search-container button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <ul>
        <li><a href="admin.php">Admin Dashboard</a></li>
        <div class="right" style="float: right;">
            <li><a href="sit_in_chart.php">Chart</a></li>
            <li><a href="Sit-in.php">Sitin</a></li>
            <li><a href="View-records.php">View Sitin Records</a></li>
            <li><a href="generate-reports.php">Generate Reports</a></li>
            <li><a href="create_announcement.php">Create Announcement</a></li>
            <li><a href="Activity2.php">Log Out</a></li>
            <li>&nbsp;&nbsp;</li>
        </div>    
    </ul>

    <div class="search-container">
        <h2>SIT-IN</h2>
        <br>
        <br>
        <form action="sitin_form.php" method="get">
            <input type="text" name="search" placeholder="Enter ID NO.">
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
