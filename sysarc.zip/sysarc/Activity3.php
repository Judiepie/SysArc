<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<title>Registration Form</title>
<style>
  body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50%;
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
        }
        form {
            background-color: #fff;
            padding: 20px;
            align-items: center;
            border-radius: 8px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        h2 {
            margin-bottom: 20px;
        }
        input[type="text"], input[type="password"], select {
            width: 100%;
            padding: 10px;
            align-items: center;
            margin-bottom: 10px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        button {
            padding: 10px 20px;
            border: none;
            background-color: #007BFF;
            color: #fff;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        
</style>

</head>
<body>
	<div class="container">
	<?php
        session_start();
        $con = mysqli_connect("localhost", "root", "", "sysarc");
        if(isset($_POST["submit"])){
            $idno = $_POST['Idno'];
            $last_name = $_POST['lastname'];
            $first_name = $_POST['firstname'];
            $middle_name = $_POST['middlename'];
            $year = $_POST['year'];
            $password = $_POST["password"];
            $Cpassword = $_POST["Cpassword"];
            $course = $_POST["course"];
            $email = $_POST["email"];
            $role = $_POST["role"];

            $errors = array();

            if (empty($idno) OR empty($last_name) OR empty($first_name) OR empty($middle_name) OR empty($year) OR empty($password) OR empty($Cpassword) OR empty($course) OR empty($email) OR empty($role)) {
                array_push($errors, "All Fields Are Required");
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                array_push($errors, "Email is not valid");
            }
            if (strlen($password)<3) {
                array_push($errors, "Password must be at below 12 characters long!!");
            }
            if ($password !== $Cpassword) {
                array_push($errors, "Password does not match");
            }

            $check_query = "SELECT * FROM user WHERE IDNO = ?";
            $check_stmt = mysqli_prepare($con, $check_query);
            mysqli_stmt_bind_param($check_stmt, "i", $idno);
            mysqli_stmt_execute($check_stmt);
            mysqli_stmt_store_result($check_stmt);
            if (mysqli_stmt_num_rows($check_stmt) > 0) {
                array_push($errors, "ID number already exists");
            }
            mysqli_stmt_close($check_stmt);

            if (count($errors)>0) {
                echo "<div class='alert alert-danger'>" . implode("<br>", $errors) . "</div>";
            } else {
                $session = 30;
                $query = "INSERT INTO user (IDNO, last_name, first_name, middle_name, year, password, course, email, role, session) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = mysqli_prepare($con, $query);
                mysqli_stmt_bind_param($stmt, "isssissssi", $idno, $last_name, $first_name, $middle_name, $year, $password, $course, $email, $role, $session);
                $result = mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
    
                if ($result) {
                    echo "<div class='alert alert-success'>Registration successful</div>";
                } else {
                    echo "<div class='alert alert-danger'>Error: " . mysqli_error($con) . "</div>";
                }
            }
        }
    ?>
    </br>
    </br>
		<div style="display: flex; flex-direction: column; align-items: center;">
    <form method="post" style="text-align: center;">
        <h2>CREATE ACCOUNT</h2>
        <input type="text" placeholder="Enter id number " name="Idno" required>
        <input type="text" placeholder="Enter last name " name="lastname" required>
        <input type="text" placeholder="Enter first name" name="firstname" required>
        <input type="text" placeholder="Enter middle name" name="middlename" required>
        <input type="text" placeholder="Enter Email" name="email" required>
        <input type="text" placeholder="Enter year" name="year" required>
        <input type="text" placeholder="Enter Course" name="course" required>
        <input type="text" placeholder="Enter Role" name="role" required>
        <input type="password" placeholder="Enter Password" name="password" required>
        <input type="password" placeholder="Confirm Password" name="Cpassword" required>
        <input type="checkbox" name="terms" id="terms" onchange="activateButton(this)">  I Agree Terms & Conditions
    </br>
        <button type="submit" name="submit">Submit</button>
        <button onclick="reset">Cancel</button>
        <h5>Have an account already? <a href="Activity2.php">Login Here!</a></h5>
    </form>
</div>

</body>
</html>