<?php
session_start();
require_once('TCPDF-main/tcpdf.php');

if (isset($_POST['generate_pdf'])) {
    // Establish database connection
    $conn = mysqli_connect("localhost", "root", "", "sysarc");

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM sitin";
    $result = mysqli_query($conn, $sql);
    $data = array();
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = array(
                $row['Idno'],
                $row['last_name'],
                $row['first_name'],
                $row['purpose'],
                $row['lab'],
                $row['date'],
                $row['TimeIn'],
                $row['Timeout'],
            );
        }
    }

    exportToPDF($data);
    exit;
}

function exportToPDF($data) {
    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // Set document information and headers
    // (Replace placeholders with your desired information)
    $pdf->SetCreator('Creator');
    $pdf->SetAuthor('Author');
    $pdf->SetTitle('Lab Session Report');
    $pdf->SetSubject('Lab Session Report');
    $pdf->SetKeywords('Lab, Session, Report');
    $pdf->setHeaderData('', 0, 'Lab Session Report', 'University of Cebu');

    // Set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

    // Set margins
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
    $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

    // Set auto page breaks
    $pdf->SetAutoPageBreak(true, PDF_MARGIN_BOTTOM);

    // Set image scale factor
    $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

    // Set font
    $pdf->SetFont('helvetica', '', 8);

    // Add a page
    $pdf->AddPage();

    // Define the table structure
    $html = '
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Last Name</th>
                <th>First Name</th>
                <th>Purpose</th>
                <th>Laboratory</th>
                <th>Date</th>
                <th>Time-in</th>
                <th>Time-out</th>
            </tr>
        </thead>
        <tbody>
    ';

    // Add data rows to the table
    foreach ($data as $rowData) {
        $html .= '<tr>';
        foreach ($rowData as $value) {
            $html .= "<td>$value</td>";
        }
        $html .= '</tr>';
    }

    $html .= '
        </tbody>
    </table>';

    // Output the HTML content
    $pdf->writeHTML($html, true, false, true, false, '');

    // Close and output PDF document
    $pdf->Output('Lab_Session_Report.pdf', 'I');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Reports</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        h1 {
            font-size: 24px;
            margin-bottom: 30px;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: none;
            display: inline-block;
        }

        li a {
            display: inline-block;
            color: white;
            text-align: left;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }

        .search-container {
            text-align: center;
            margin-top: 50px;
        }

        .search-container input[type=text], .search-container select {
            width: 30%;
            padding: 12px;
            margin: 8px 5px;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
        }

        .search-container button {
            width: 10%;
            padding: 12px;
            margin: 8px 5px;
            box-sizing: border-box;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }

        .search-container button:hover {
            background-color: #0056b3;
        }

        .pagination {
            text-align: center;
            margin-top: 20px;
        }

        .pagination a {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            color: black;
        }

        .pagination a.active {
            background-color: #007bff;
            color: white;
        }

        .pagination a:hover:not(.active) {
            background-color: #ddd;
        }

        .pagination-button {
            margin-top: 20px;
            text-align: center;
        }

        .pagination-button button {
            margin: 0 5px;
        }
    </style>
</head>
<body>
<ul>
    <li><a href="admin.php">Admin Dashboard</a></li>
    <div class="right" style="float: right;">
        <li><a href="sit_in_chart.php">Chart</a></li>
        <li><a href="Sit-in.php">Sitin</a></li>
        <li><a href="View-records.php">View Sitin Records</a></li>
        <li><a href="generate-reports.php">Generate Reports</a></li>
        <li><a href="create_announcement.php">Create Announcement</a></li>
        <li><a href="Activity2.php">Log Out</a></li>
        <li>&nbsp;&nbsp;</li>
    </div>
</ul>
<div class="container">
    <h1>Sit-in Reports</h1>
    <div class="search-container">
        <form action="generate-reports.php" method="post">
            <input type="text" name="date" placeholder="Enter Date (YYYY-MM-DD)">
            <input type="text" name="purpose" placeholder="Enter Purpose">
            <input type="text" name="lab" placeholder="Enter Lab">
            <button type="submit">Filter</button>
        </form>
        <form method="post" action="">
            <input type="hidden" name="generate_pdf" value="1">
            <button type="submit" class="btn btn-primary mt-2" name="generate_pdf">Print</button>
        </form>
    </div>
    <br>
    <br>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Last Name</th>
                <th>First Name</th>
                <th>Purpose</th>
                <th>Lab</th>
                <th>Date</th>
                <th>Time In</th>
                <th>Time Out</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Connect to database
            $con = mysqli_connect("localhost", "root", "", "sysarc");

            if (!$con) {
                die("Connection failed: " . mysqli_connect_error());
            }

            // Define pagination variables
            $records_per_page = isset($_POST['records_per_page']) ? $_POST['records_per_page'] : 5;
            $page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;

            // Initialize filter variables
            $date = isset($_POST['date']) ? $_POST['date'] : '';
            $purpose = isset($_POST['purpose']) ? $_POST['purpose'] : '';
            $lab = isset($_POST['lab']) ? $_POST['lab'] : '';

            // Prepare SQL query with filter conditions
            $sql = "SELECT * FROM sitin WHERE 1=1";
            if (!empty($date)) {
                $sql .= " AND date = '$date'";
            }
            if (!empty($purpose)) {
                $sql .= " AND purpose LIKE '%$purpose%'";
            }
            if (!empty($lab)) {
                $sql .= " AND lab LIKE '%$lab%'";
            }

            // Execute SQL query with pagination
            $start_from = ($page - 1) * $records_per_page;
            $sql .= " LIMIT $start_from, $records_per_page";

            $result = mysqli_query($con, $sql);

            // Check if there are records to display
            if (mysqli_num_rows($result) > 0) {
                // Output data of each row
                while($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row["Idno"] . "</td>";
                    echo "<td>" . $row["last_name"] . "</td>";
                    echo "<td>" . $row["first_name"] . "</td>";
                    echo "<td>" . $row["purpose"] . "</td>";
                    echo "<td>" . $row["lab"] . "</td>";
                    echo "<td>" . $row["date"] . "</td>";
                    echo "<td>" . $row["TimeIn"] . "</td>";
                    echo "<td>" . $row["Timeout"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No records found</td></tr>";
            }

            // Pagination links
            $total_pages_sql = "SELECT COUNT(*) AS total FROM sitin";
            $total_pages_result = mysqli_query($con, $total_pages_sql);
            $total_rows = mysqli_fetch_assoc($total_pages_result)['total'];
            $total_pages = ceil($total_rows / $records_per_page);

            echo "<div class='pagination'>";
            for ($i = 1; $i <= $total_pages; $i++) {
                echo "<a href='generate-reports.php?page=$i'>$i</a>";
            }
            echo "</div>";

            // Close connection
            mysqli_close($con);
            ?>
        </tbody>
    </table>
    <form action="generate-reports.php" method="post" class="pagination-button">
        <label for="records_per_page">Records per Page:</label>
        <select name="records_per_page" id="records_per_page">
            <option value="5">5</option>
            <option value="10">10</option>
            <option value="20">20</option>
            <option value="50">50</option>
        </select>
        <button type="submit">Apply</button>
    </form>
</div>
</body>
</html>
