<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "sysarc");

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $con->real_escape_string($_POST["title"]);
    $content = $con->real_escape_string($_POST["content"]);

    $sql = "INSERT INTO announcements (title, content, date_created) VALUES ('$title', '$content', NOW())";

    if ($con->query($sql) === TRUE) {
        echo "New announcement created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
    }
}

$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Announcement</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            max-width: 500px;
            margin: auto;
        }
        form div {
            margin-bottom: 15px;
        }
        form div label {
            display: block;
            margin-bottom: 5px;
        }
        form div input, form div textarea {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
        }
        form div button {
            padding: 10px 15px;
            background-color: #007BFF;
            border: none;
            color: #fff;
            cursor: pointer;
        }
        form div button:hover {
            background-color: #0056b3;
        }
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: none;
            display: inline-block;
        }

        li a {
            display: inline-block;
            color: white;
            text-align: left;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }

        .search-container {
            text-align: center;
            margin-top: 50px;
        }

        .search-container input[type=text] {
            width: 70%;
            padding: 12px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
        }

        .search-container button {
            width: 20%;
            padding: 12px;
            margin: 8px 0;
            box-sizing: border-box;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }

        .search-container button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<ul>
    <li><a href="admin.php">Admin Dashboard</a></li>
    <div class="right" style="float: right;">
        <li><a href="sit_in_chart.php">Chart</a></li>
        <li><a href="Sit-in.php">Sitin</a></li>
        <li><a href="View-records.php">View Sitin Records</a></li>
        <li><a href="generate-reports.php">Generate Reports</a></li>
        <li><a href="create_announcement.php">Create Announcement</a></li>
        <li><a href="Activity2.php">Log Out</a></li>
        <li>&nbsp;&nbsp;</li>
    </div>    
    </ul>
    <h1>Create Announcement</h1>
    <form method="post" action="">
        <div>
            <label for="title">Title</label>
            <input type="text" id="title" name="title" required>
        </div>
        <div>
            <label for="content">Content</label>
            <textarea id="content" name="content" rows="5" required></textarea>
        </div>
        <div>
            <button type="submit">Create Announcement</button>
        </div>
    </form>
</body>
</html>