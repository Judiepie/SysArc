<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "sysarc");



if (isset($_POST["login"])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM user WHERE email = '$email'";
    $result = mysqli_query($con, $sql);
    $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
    
    if ($user) {
        if ($password == $user["password"]) {
            $_SESSION['last_name'] = $user['last_name'];
            $_SESSION['Idno'] = $user['Idno'];
            // Redirect based on user type
            if ($email == "admin" && $password == "123") {
                $_SESSION["email"] = "admin";
                $_SESSION["password"] = "123";
                header("Location: admin.php");
            } else {
                header("Location: Student.php");
            }
        } else {
            echo "<div class='alert alert-danger'>PASSWORD INCORRECT</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Email Does Not Exist</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<title>User Login Interface</title>
<style> 
 body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            
        }

        
        form {
            background-color: #fff;
            padding: 20px;
            width: 40%;  /* Adjust this value */
            border-radius: 8px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
            text-align: center;
            margin-block: 30%, 30%;
            margin-inline: 30% 30%;
            inset: 30%;
        }
        h2 {
            margin-bottom: 20px;
        }
        img {
            width: 80px;
            height: 80px;
            border-radius: 100px;
            margin-bottom: 20px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        button {
            padding: 10px 20px;
            border: none;
            background-color: #007BFF;
            color: #fff;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        
        
</style>
    
</head>
<body>
<br />
<br />
<br />
<br />
	<div class="container">
	<form method="post">
        <h2>Login</h2>
        <img src="https://static.vecteezy.com/system/resources/thumbnails/007/033/146/small/profile-icon-login-head-icon-vector.jpg">
        <input type="text" placeholder="Enter Email" name="email" required>
        <input type="password" placeholder="Enter Password" name="password" required>
        <button type="submit" name="login">Login</button>
        <h5>No account? Click <a href="Activity3.php">here!</a></h5>
    </form>
    </div>
</body>
</html>