<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title>Student Dashboard</title>

    <script>
        swal({
            title: "You have logged in successfully!",
            text: "Click the button to continue!",
            icon: "success",
        });
    </script>
<style>
body {
    font-family: "Poppins", sans-serif;
    background-color: #f9f9f9;
    margin: 0;
    padding: 0;
    color: #333;
}

.container {
    max-width: 800px;
    margin: 0 auto;
    padding: 40px;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    display: inline-block;
}

li a {
    display: inline-block;
    color: white;
    text-align: left;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}

.mb-2 {
    margin-bottom: 10px;
}

.bg-slate-200 {
    background-color: #f0f4f8;
}

.shadow-md {
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
}

.font-semibold {
    font-weight: 600;
}

.text-lg {
    font-size: 1.125rem;
}

.text-center {
    text-align: center;
}

.pl-6 {
    padding-left: 24px;
}


</style>
</head>
<body>
    <ul>
        <li><a href="Student.php">Student Dashboard</a></li>
        <div class="right" style="float: right;">
            <li><a href="edit-profile.php">Edit Profile</a></li>
            <li><a href="student-history.php">History</a></li>
            <li><a href="session.php">Session</a></li>
            <li><a href="announcement.php">Announcement</a></li>
            <li><a href="Activity2.php">Log Out</a></li>
            <li>&nbsp;&nbsp;</li>
        </div>    
    </ul>
</div>
</div>
<div class=" mt-8 bg-white rounded-lg shadow-lg p-8 mx-28 w-full">
        <h2 class="text-2xl font-semibold mb-4 text-center">LABORATORY RULES AND REGULATIONS</h2>
        <ol class="list-decimal pl-6">
            <li class="mb-2">Maintain silence, proper decorum, and discipline inside the laboratory. Mobile phones, walkmans and other personal pieces of equipment must be switched off.</li>
            <li class="mb-2">Games are not allowed inside the lab. This includes computer-related games, card games and other games that may disturb the operation of the lab.</li>
            <li class="mb-2">Surfing the Internet is allowed only with the permission of the instructor. Downloading and installing of software are strictly prohibited.</li>
            <li class="mb-2">Getting access to other websites not related to the course (especially pornographic and illicit sites) is strictly prohibited.</li>
            <li class="mb-2">Deleting computer files and changing the set-up of the computer is a major offense.</li>
            <li class="mb-2">Observe computer time usage carefully. A fifteen-minute allowance is given for each use. Otherwise, the unit will be given to those who wish to “sit-in”.</li>
            <li class="mb-2">Observe proper decorum while inside the laboratory:
                <ol class="list-disc pl-6">
                    <li>Do not get inside the lab unless the instructor is present.</li>
                    <li>All bags, knapsacks, and the likes must be deposited at the counter.</li>
                    <li>Follow the seating arrangement of your instructor.</li>
                    <li>At the end of class, all software programs must be closed.</li>
                    <li>Return all chairs to their proper places after using.</li>
                </ol>
            </li>
            <li class="mb-2">Chewing gum, eating, drinking, smoking, and other forms of vandalism are prohibited inside the lab.</li>
            <li class="mb-2">Anyone causing a continual disturbance will be asked to leave the lab. Acts or gestures offensive to the members of the community, including public display of physical intimacy, are not tolerated.</li>
            <li class="mb-2">Persons exhibiting hostile or threatening behavior such as yelling, swearing, or Disregarding requests made by lab personnel will be asked to leave the lab.</li>
            <div class="bg-slate-200 p-6 rounded-lg shadow-md">
            <h2 class="text-lg font-semibold mb-4">DISCIPLINARY ACTION</h2>
            <p class="mb-2"><strong>First Offense:</strong> The Head or the Dean or OIC recommends to the Guidance Center for a suspension from classes for each offender.</p>
            <p class="mb-2"><strong>Second and Subsequent Offenses:</strong> A recommendation for a heavier sanction will be endorsed to the Guidance Center.</p>
            <br>
        </div>
        </ol>
    </div>
</div>
<br>
</body>
</html>