<?php

$con = mysqli_connect("localhost", "root", "", "sysarc");


// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sit-in Form</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        h1 {
            font-size: 24px;
            margin-bottom: 30px;
            text-align: center;
        }
        .form-label {
            font-weight: bold;
        }
        .form-control {
            border-radius: 4px;
        }
        .btn-primary {
            width: 100%;
            margin-top: 20px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <?php
    if(isset($_GET['search'])) {
        $id = $_GET['search'];
        $con = mysqli_connect("localhost", "root", "", "sysarc");

        if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql = "SELECT * FROM user WHERE Idno = '$id'";
        $result = mysqli_query($con, $sql);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $lastName = $row['last_name'];
            $firstName = $row['first_name'];
            $session = $row['session'];
    ?>
    <div class="container">
        <h1>Sit-in Form</h1>
        <form action="sitin_form.php" method="post"> <!-- Added method="post" -->
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="mb-3">
                <label for="lastName" class="form-label">Last Name:</label>
                <input type="text" class="form-control" id="lastName" name="lastName" value="<?php echo $lastName; ?>" readonly>
            </div>
            <div class="mb-3">
                <label for="firstName" class="form-label">First Name:</label>
                <input type="text" class="form-control" id="firstName" name="firstName" value="<?php echo $firstName; ?>" readonly>
            </div>
            <div class="mb-3">
                <label for="purpose" class="form-label">Purpose:</label>
                <input type="text" class="form-control" id="purpose" name="purpose">
            </div>
            <div class="mb-3">
                <label for="lab" class="form-label">Lab:</label>
                <input type="text" class="form-control" id="lab" name="lab">
            </div>
            <div class="mb-4">
                <label for="session" class="form-label">Remaining Session:</label>
                <input type="text" class="form-control" id="session" name="session" value="<?php echo $session; ?>" readonly>
            </div>

            <button type="submit" class="btn btn-primary">Sit-in</button>
        </form>
    </div>
    <?php
        } else {
            echo "Student not found.";
        }
    }
    ?>

    <?php
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['id'];
        $lastName = $_POST['lastName'];
        $firstName = $_POST['firstName'];
        $purpose = $_POST['purpose'];
        $lab = $_POST['lab'];
        $session = $_POST['session'];
        $timeIn = date("Y-m-d H:i:s");
        
        $con = mysqli_connect("localhost", "root", "", "sysarc");

        if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql = "INSERT INTO `sitin` (`Idno`, `last_name`, `first_name`, `purpose`, `lab`, `TimeIn`, `Timeout`) VALUES ('$id', '$lastName', '$firstName', '$purpose', '$lab', '$timeIn', NULL)";

        if(mysqli_query($con, $sql)) {
            header("Location: View-records.php");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($con);
        }

        mysqli_close($con);
    }
    ?>
</body>
</html>
