<?php
session_start();

$con = mysqli_connect("localhost", "root", "", "sysarc");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['id'])) {
        $studentId = $_POST['id'];
        
        $timeout = date('H:i:s', strtotime('+30 minutes'));
        
        // Update the TimeIn and Timeout fields for the student in the database
        $updateSql = "UPDATE sitin SET TimeIn = CURRENT_TIME(), Timeout = '$timeout' WHERE Idno = $studentId";
        if (mysqli_query($con, $updateSql)) {
            echo "success";
        } else {
            echo "error";
        }
    } elseif (isset($_POST['delete_id'])) {
        $deleteId = $_POST['delete_id'];
        
        // Delete the record from the database
        $deleteSql = "DELETE FROM sitin WHERE Idno = $deleteId";
        if (mysqli_query($con, $deleteSql)) {
            echo "success";
        } else {
            echo "error";
        }
    } elseif (isset($_POST['logout_id'])) {
        $logoutId = $_POST['logout_id'];
        
        // Get the current time
        $currentTime = date('H:i:s');
        
        // Update the Timeout field by deducting the time difference
        $updateSql = "UPDATE sitin SET Timeout = '$currentTime' WHERE Idno = $logoutId";
        $sessionSql = "UPDATE user SET session = session - 1 WHERE Idno = $logoutId";

        if (mysqli_query($con, $updateSql) && mysqli_query($con, $sessionSql)) {
            echo "success";
        } else {
            echo "error";
        }
    }
    exit; // Stop further execution
}

$sql = "SELECT * FROM sitin";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Sit-in Records</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Include SweetAlert JS -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <style>
      ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: none;
    display: inline-block;
}

li a {
    display: inline-block;
    color: white;
    text-align: left;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}

.search-container {
    text-align: center;
    margin-top: 50px;
}

.search-container input[type=text] {
    width: 70%;
    padding: 12px;
    margin: 8px 0;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
}

.search-container button {
    width: auto; /* Adjust width automatically based on content */
    padding: 12px 20px; /* Adjust padding for better button appearance */
    margin: 8px 0;
    box-sizing: border-box;
    border: none;
    background-color: #007bff;
    color: white;
    border-radius: 4px;
    cursor: pointer;
}

.search-container button:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>
    <ul>
        <li><a href="admin.php">Admin Dashboard</a></li>
        <div class="right" style="float: right;">
            <li><a href="sit_in_chart.php">Chart</a></li>
            <li><a href="Sit-in.php">Sitin</a></li>
            <li><a href="View-records.php">View Sitin Records</a></li>
            <li><a href="generate-reports.php">Generate Reports</a></li>
            <li><a href="create_announcement.php">Create Announcement</a></li>
            <li><a href="Activity2.php">Log Out</a></li>
            <li>&nbsp;&nbsp;</li>
        </div>    
    </ul>

    <div class="search-container">
        <div class="container">
        <h2 class="text-center mt-5">View Sitin Records</h2>
        <div class="table-responsive mt-3">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Last Name</th>
                        <th>First Name</th>
                        <th>Purpose</th>
                        <th>Lab</th>
                        <th>Date</th>
                        <th>Time In</th>
                        <th>Time Out</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['Idno'] . "</td>";
                            echo "<td>" . $row['last_name'] . "</td>";
                            echo "<td>" . $row['first_name'] . "</td>";
                            echo "<td>" . $row['purpose'] . "</td>";
                            echo "<td>" . $row['lab'] . "</td>";
                            echo "<td>" . $row['date'] . "</td>";
                            echo "<td>" . $row['TimeIn'] . "</td>";
                            echo "<td>" . $row['Timeout'] . "</td>";
                            echo "<td>
                                    <button class='btn btn-primary logout-btn' data-id='" . $row['Idno'] . "'>Logout</button>
                                    <button class='btn btn-danger delete-btn' data-id='" . $row['Idno'] . "'>Delete</button>
                                  </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $('.logout-btn').click(function(){
                var logoutId = $(this).data('id');
                $.ajax({
                    url: window.location.href, // Send request to the same page
                    type: 'POST',
                    data: {logout_id: logoutId},
                    success: function(response) {
                        // Handle success, e.g., display a success message
                        if (response === 'success') {
                            alert("Student with ID " + logoutId + " has been logged out.");
                            // You might also want to update the UI to reflect the logout action
                        } else {
                            alert("Error occurred while logging out student.");
                        }
                    },
                    error: function(xhr, status, error) {
                        // Handle error, e.g., display an error message
                        console.error(xhr.responseText);
                    }
                });
            });

            $('.delete-btn').click(function(){
                var deleteId = $(this).data('id');
                if (confirm("Are you sure you want to delete this record?")) {
                    $.ajax({
                        url: window.location.href, // Send request to the same page
                        type: 'POST',
                        data: {delete_id: deleteId},
                        success: function(response) {
                            // Handle success, e.g., remove the deleted row from the table
                            if (response === 'success') {
                                alert("Record with ID " + deleteId + " has been deleted.");
                                // Remove the deleted row from the table
                                $('tr[data-id="' + deleteId + '"]').remove();
                            } else {
                                alert("Error occurred while deleting the record.");
                            }
                        },
                        error: function(xhr, status, error) {
                            // Handle error, e.g., display an error message
                            console.error(xhr.responseText);
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>

<?php
mysqli_close($con);
?>
