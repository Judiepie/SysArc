<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "sysarc");



if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["submit"])) {
        $search_query = $_POST['search_query'];
        // Perform search query here and display results
        $sql = "SELECT * FROM user WHERE Idno LIKE '%$search_query%'";
        $result = mysqli_query($con, $sql);

        if (mysqli_num_rows($result) > 0) {
            echo "<div class='container mt-3'><table class='table'><thead><tr><th>ID</th><th>Name</th><th>Course</th><th>Year</th><th>Session</th><th>Action</th></tr></thead><tbody>";

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr><td>".$row['Idno']."</td><td>".$row['last_name']." ".$row['first_name']." ".$row['middle_name']."</td><td>".$row['course']."</td><td>".$row['year']."</td><td>".$row['session']."</td>";
                echo "<td><button class='btn btn-danger' onclick=\"deleteRecord('".$row['Idno']."')\">Delete</button></td></tr>";
            }

            echo "</tbody></table></div>";
        } else {
            echo "<div class='container mt-3'><p>No results found.</p></div>";
        }
    }

    if (isset($_POST['delete_id'])) {
        $id_to_delete = $_POST['delete_id'];
        // Perform delete operation
        $sql_delete = "DELETE FROM user WHERE Idno = '$id_to_delete'";
        if (mysqli_query($con, $sql_delete)) {
            echo "<script>alert('Record Deleted!');</script>";
        } else {
            echo "<script>alert('Error: There was an error deleting the record.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title>Admin Dashboard</title>

    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: none;
            display: inline-block;
        }

        li a {
            display: inline-block;
            color: white;
            text-align: left;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }

        .search-container {
            text-align: center;
            margin-top: 50px;
        }

        .search-container input[type=text] {
            width: 70%;
            padding: 12px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
        }

        .search-container button {
            width: 20%;
            padding: 12px;
            margin: 8px 0;
            box-sizing: border-box;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }

        .search-container button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <ul>
        <li><a href="#">Admin Dashboard</a></li>
        <div class="right" style="float: right;">
            <li><a href="sit_in_chart.php">Chart</a></li>
            <li><a href="Sit-in.php">Sitin</a></li>
            <li><a href="View-records.php">View Sitin Records</a></li>
            <li><a href="generate-reports.php">Generate Reports</a></li>
            <li><a href="create_announcement.php">Create Announcement</a></li>
            <li><a href="view_feedback.php">View Feedbacks</a></li>
            <li><a href="Reset-session.php">Reset Session</a></li>
            <li><a href="Activity2.php">Log Out</a></li>
            <li>&nbsp;&nbsp;</li>
        </div>    
    </ul>
    
    <div class="search-container">
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <h2>Search</h2>
        </br>
        </br>
            <input type="text" name="search_query" placeholder="Enter ID NO.">
            <button type="submit" name="submit" class="btn btn-primary">Search</button>
        </form>
    </div>

    
    <script>
        function deleteRecord(id) {
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this record!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    // Perform delete operation
                    document.getElementById('delete_id').value = id;
                    document.getElementById('delete_form').submit();
                }
            });
        }
    </script>

    <!-- Hidden form to handle deletion -->
    <form id="delete_form" method="POST" style="display: none;">
        <input type="hidden" id="delete_id" name="delete_id">
    </form>
</body>
</html>
