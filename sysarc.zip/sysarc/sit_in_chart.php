<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sit-In Purposes Pie Chart</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f4;
        }
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            width: 100%;
            background-color: #333;
            overflow: hidden;
        }
        ul li {
            float: left;
        }
        ul li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
        ul li a:hover {
            background-color: #111;
        }
        .right {
            float: right;
        }
        .container {
            text-align: center;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        h2 {
            margin-bottom: 20px;
        }
        canvas {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <ul>
        <li><a href="admin.php">Admin Dashboard</a></li>
        <div class="right">
            <li><a href="sit_in_chart.php">Chart</a></li>
            <li><a href="Sit-in.php">Sitin</a></li>
            <li><a href="View-records.php">View Sitin Records</a></li>
            <li><a href="generate-reports.php">Generate Reports</a></li>
            <li><a href="create_announcement.php">Create Announcement</a></li>
            <li><a href="view_feedback.php">View Feedbacks</a></li>
            <li><a href="Reset-session.php">Reset Session</a></li>
            <li><a href="Activity2.php">Log Out</a></li>
        </div>
    </ul>
    
    <div class="container">
        <h2>Distribution of Sit-In Purposes</h2>
        <canvas id="sitInChart" width="300" height="300"></canvas>
    </div>

    <?php
    session_start();
    $conn = mysqli_connect("localhost", "root", "", "sysarc");

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch data from the database
    $sql = "SELECT purpose, COUNT(*) as count FROM sitin GROUP BY purpose";
    $result = $conn->query($sql);

    $purposes = array();
    $counts = array();

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $purposes[] = $row['purpose'];
            $counts[] = $row['count'];
        }
    }

    $conn->close();
    ?>

    <script>
        var ctx = document.getElementById('sitInChart').getContext('2d');
        var sitInChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($purposes); ?>,
                datasets: [{
                    label: 'Sit-In Purposes',
                    data: <?php echo json_encode($counts); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(99, 255, 132, 0.2)',
                        'rgba(162, 54, 235, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)',
                        'rgba(99, 255, 132, 1)',
                        'rgba(162, 54, 235, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                let total = context.dataset.data.reduce((a, b) => a + b, 0);
                                let value = context.raw;
                                let percentage = ((value / total) * 100).toFixed(1);
                                label += `${value} (${percentage}%)`;
                                return label;
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
