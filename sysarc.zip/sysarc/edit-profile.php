<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "sysarc");

if (isset($_POST["update"])) {
    $idno = $_POST['Idno'];
    $last_name = $_POST['lastname'];
    $first_name = $_POST['firstname'];
    $middle_name = $_POST['middlename'];
    $year = $_POST['year'];
    $password = $_POST["password"];
    $course = $_POST["course"];
    $email = $_POST["email"];

    $errors = array();

    if (empty($idno) || empty($last_name) || empty($first_name) || empty($middle_name) || empty($year) || empty($password) || empty($course) || empty($email)) {
        array_push($errors, "All Fields Are Required");
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        array_push($errors, "Email is not valid");
    }
    if (strlen($password) < 8) {
        array_push($errors, "Password must be at least 8 characters long!!");
    }

    if (count($errors) > 0) {
        echo "<div class='alert alert-danger'>" . implode("<br>", $errors) . "</div>";
    } else {
        $query = "UPDATE `user` SET `last_name` = '$last_name', `first_name` = '$first_name', `middle_name` = '$middle_name', `year` = '$year', `password` = '$password', `course` = '$course', `email` = '$email' WHERE `IDNO` = '$idno'";
        if (mysqli_query($con, $query)) {
            echo "Profile updated successfully";
        } else {
            echo "Error updating profile: " . mysqli_error($con);
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Edit Profile</title>
    <style>

    {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}


.container {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f9f9f9;
}


form {
    display: flex;
    flex-direction: column;
}

input[type="text"],
input[type="password"] {
    margin-bottom: 10px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

button {
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 3px;
    padding: 10px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #0056b3;
}


h2 {
    text-align: center;
    font-family: Arial, sans-serif;
    margin-bottom: 20px;
}
.back-button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    text-decoration: none; 
    display: block; 
    margin: 0 auto; 
    width: fit-content; 
}
.back-button:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>
<div class="container">
        <h2>Edit Profile</h2>
        <form method="post">
            <input type="text" placeholder="ID number" name="Idno" required>
            <input type="text" placeholder="Last name" name="lastname" required>
            <input type="text" placeholder="First name" name="firstname" required>
            <input type="text" placeholder="Middle name" name="middlename" required>
            <input type="text" placeholder="Email" name="email" required>
            <input type="text" placeholder="Year" name="year" required>
            <input type="text" placeholder="Course" name="course" required>
            <input type="password" placeholder="Password" name="password" required>
            <button type="submit" name="update">Update</button>
            <br>
            <a href="Student.php" class="back-button">Back</a>
        </form>
    </div>
</body>
</html>
