<?php
session_start();

// Establish database connection
$con = mysqli_connect("localhost", "root", "", "sysarc");

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Update session value for all students to 30
$sql = "UPDATE user SET session = 30";
if (mysqli_query($con, $sql)) {
    $message = "Sessions reset successfully.";
} else {
    $error = "Error updating sessions: " . mysqli_error($con);
}

// Close database connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Sessions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        h2 {
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
        }
        .message {
            color: green;
            text-align: center;
        }
        .error {
            color: red;
            text-align: center;
        }
        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Reset Sessions</h2>
        <?php if(isset($message)) { ?>
            <p class="message"><?php echo $message; ?></p>
        <?php } ?>
        <?php if(isset($error)) { ?>
            <p class="error"><?php echo $error; ?></p>
        <?php } ?>
        <div style="text-align: center;">
            <button onclick="window.location.href='admin.php'">Back to Home</button>
        </div>
    </div>
</body>
</html>
