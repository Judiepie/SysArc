<?php
session_start();

$con = mysqli_connect("localhost", "root", "", "sysarc");

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle feedback submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_SESSION["Idno"])) {
        $studID = $_SESSION["Idno"];
        $content = mysqli_real_escape_string($con, $_POST["content"]);

        $sql = "INSERT INTO feedback (Idno, content, date_created) VALUES ('$studID', '$content', NOW())";

        if (mysqli_query($con, $sql)) {
            echo "<script>alert('Feedback submitted successfully');</script>";
        } else {
            echo "<script>alert('Error submitting feedback: " . mysqli_error($con) . "');</script>";
        }
    } else {
        echo "<script>alert('Student ID not found in session');</script>";
    }
}

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        h1 {
            font-size: 24px;
            margin-bottom: 30px;
            text-align: center;
        }
        .form-label {
            font-weight: bold;
        }
        .form-control {
            border-radius: 4px;
        }
        .btn-primary {
            width: 100%;
            margin-top: 20px;
            border-radius: 4px;
        }
        ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    display: inline-block;
}

li a {
    display: inline-block;
    color: white;
    text-align: left;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}
    </style>
</head>
<body>
<ul>
    <li><a href="Student.php">Student Dashboard</a></li>
        <div class="right" style="float: right;">
            <li><a href="edit-profile.php">Edit Profile</a></li>
            <li><a href="student-history.php">History</a></li>
            <li><a href="session.php">Session</a></li>
            <li><a href="announcement.php">Announcement</a></li>
            <li><a href="Activity2.php">Log Out</a></li>
            <li>&nbsp;&nbsp;</li>
        </div>    
    </ul>
    <div class="container">
        <h1>Feedback Form</h1>
        <form method="post">
            <div class="mb-3">
                <label for="content" class="form-label">Your Feedback:</label>
                <textarea class="form-control" id="content" name="content" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit Feedback</button>
        </form>
    </div>
</body>
</html>
