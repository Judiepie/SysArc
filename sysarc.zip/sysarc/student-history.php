<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>History of Your Sit-ins</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
    }
    .container {
      max-width: 800px;
      margin: 50px auto;
      padding: 20px;
      border-radius: 8px;
      background-color: #fff;
      box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
    }
    h1 {
      font-size: 24px;
      margin-bottom: 30px;
      text-align: center;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f2f2f2;
    }
    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: #333;
    }

    li {
      float: none;
      display: inline-block;
    }

    li a {
      display: inline-block;
      color: white;
      text-align: left;
      padding: 14px 16px;
      text-decoration: none;
    }

    li a:hover {
      background-color: #111;
    }

    .feedback-btn {
      display: inline-block;
      margin-left: 10px;
    }

  </style>
</head>
<body>
<ul>
  <li><a href="Student.php">Student Dashboard</a></li>
  <div class="right" style="float: right;">
    <li><a href="edit-profile.php">Edit Profile</a></li>
    <li><a href="student-history.php">History</a></li>
    <li><a href="session.php">Session</a></li>
    <li><a href="announcement.php">Announcement</a></li>
    <li><a href="Activity2.php">Log Out</a></li>
    <li>&nbsp;&nbsp;</li>
  </div>
</ul>
<div class="container">
  <h1>History of Your Sit-ins</h1>
  <table>
    <thead>
    <tr>
      <th>ID</th>
      <th>Last Name</th>
      <th>First Name</th>
      <th>Purpose</th>
      <th>Lab</th>
      <th>Date</th>
      <th>Time In</th>
      <th>Time Out</th>
      <th>Feedback</th>
    </tr>
    </thead>
    <tbody>
    <?php
    // Connect to database
    $con = mysqli_connect("localhost", "root", "", "sysarc");

    if (!$con) {
      die("Connection failed: " . mysqli_connect_error());
    }

    $Idno = $_SESSION['Idno'];
    // Fetch only your sit-ins (assuming a 'user_id' column exists in the user table)
    $sql = "SELECT * FROM sitin WHERE Idno = '$Idno'";
    $result = mysqli_query($con, $sql);

    // Check if there are records to display
    if (mysqli_num_rows($result) > 0) {
      // Output data of each row
      while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row["Idno"] . "</td>";
        echo "<td>" . $row["last_name"] . "</td>";
        echo "<td>" . $row["first_name"] . "</td>";
        echo "<td>" . $row["purpose"] . "</td>";
        echo "<td>" . $row["lab"] . "</td>";
        echo "<td>" . $row["date"] . "</td>";
        echo "<td>" . $row["TimeIn"] . "</td>";
        echo "<td>" . $row["Timeout"] . "</td>";
        // Feedback button
        echo "<td>";
        echo "<form action='feedback_form.php' method='GET' class='feedback-btn'>";
        echo "<input type='hidden' name='sit_id' value='" . $row["sit_id"] . "'>";
        echo "<input type='hidden' name='timeout' value='" . $row["Timeout"] . "'>"; // Add this line
        echo "<button type='submit' class='btn btn-primary'>Feedback</button>";
        echo "</form>";
        echo "</td>";
        echo "</tr>";
      }
    } else {
      echo "<tr><td colspan='9'>No records found</td></tr>";
    }

    // Close connection
    mysqli_close($con);
    ?>
    </tbody>
  </table>
</div>
</body>
</html>
