-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2024 at 02:46 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sysarc`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `content`, `date_created`) VALUES
(5, 'NO CLASSES', 'There\'s no classes', '2024-05-24 11:05:00');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Idno` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Idno`, `student_id`, `content`, `date_created`) VALUES
(21458110, 21572941, 'Good evening sir, I have concern about tonight', '2024-05-26 12:45:24');

-- --------------------------------------------------------

--
-- Table structure for table `sitin`
--

CREATE TABLE `sitin` (
  `sit_id` int(11) NOT NULL,
  `Idno` int(8) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `purpose` varchar(20) NOT NULL,
  `lab` varchar(20) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `TimeIn` time NOT NULL DEFAULT current_timestamp(),
  `Timeout` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sitin`
--

INSERT INTO `sitin` (`sit_id`, `Idno`, `last_name`, `first_name`, `purpose`, `lab`, `date`, `TimeIn`, `Timeout`) VALUES
(17, 21458104, 'Sandalo', 'Jude Jefferson', 'JAVA PROGRAMMING', '526A', '2024-05-24', '04:41:24', '14:35:16'),
(18, 21458104, 'Sandalo', 'Jude Jefferson', 'PYTHON PROGRAMMING', '526A', '2024-05-24', '04:54:44', '14:35:16'),
(43, 21700120, 'Baculao', 'Kyle Yvan', 'JAVA PROGRAMMING', '520A', '2024-05-24', '05:42:00', '14:29:17'),
(44, 21700120, 'Baculao', 'Kyle Yvan', 'JAVA PROGRAMMING', '520A', '2024-05-26', '14:28:46', '14:29:17'),
(45, 21700120, 'Baculao', 'Kyle Yvan', 'PYTHON PROGRAMMING', '520A', '2024-05-26', '14:29:14', '14:29:17'),
(46, 21458104, 'Sandalo', 'Jude Jefferson', 'JAVA PROGRAMMING', '520A', '2024-05-26', '14:35:14', '14:35:16'),
(47, 1231231, 'andrade', 'john', 'JAVA PROGRAMMING', '526A', '2024-05-26', '14:40:16', '14:40:29'),
(48, 1231231, 'andrade', 'john', 'PYTHON PROGRAMMING', '520A', '2024-05-26', '14:40:27', '14:40:29'),
(49, 21572941, 'Imai', 'Nero', 'C++ PROGRAMMING', '528A', '2024-05-26', '14:44:08', '14:44:49'),
(50, 21572941, 'Imai', 'Nero', 'JAVA PROGRAMMING', '528A', '2024-05-26', '14:44:33', '14:44:49'),
(51, 21572941, 'Imai', 'Nero', 'PYTHON PROGRAMMING', '526A', '2024-05-26', '14:44:47', '14:44:49');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Idno` int(8) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `year` int(11) NOT NULL,
  `password` varchar(50) NOT NULL,
  `Cpassword` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `session` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Idno`, `last_name`, `first_name`, `middle_name`, `year`, `password`, `Cpassword`, `course`, `email`, `role`, `session`) VALUES
(1231231, 'andrade', 'john', 'jeric', 4, '123', '', 'BSIT', 'john@gmail.com', 'Student', 28),
(21429394, 'Managaytay', 'Shyrelle Shine', 'Lumacang', 4, '123', '', 'BSIT', 'mshyrelleshine@gmail.com', 'Student', 30),
(21458104, 'Sandalo', 'Jude Jefferson', 'Canama', 3, '123', '', 'BSIT', 'judeketchup@gmail.com', 'STUDENT', 29),
(21572941, 'Imai', 'Nero', 'F', 1, '123', '', 'BSAC', 'NeroImai@gmail.com', 'Student', 26),
(21700120, 'Baculao', 'Kyle Yvan', 'Bobo', 1, '123', '', 'BSHM', 'kyleyvan@gmail.com', 'Student', 30),
(211053917, 'Canedo', 'Gilbert', 'Rigor', 3, '123', '', 'BSIT', 'GilbertCanedo@gmail.com', 'Student', 30),
(231231231, 'Gastardo', 'Generoso', 'D', 4, '123', '', 'BSIT', 'GeneGastardoJr@gmail.com', 'Student', 30);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD UNIQUE KEY `Idno` (`Idno`);

--
-- Indexes for table `sitin`
--
ALTER TABLE `sitin`
  ADD PRIMARY KEY (`sit_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Idno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `Idno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21458111;

--
-- AUTO_INCREMENT for table `sitin`
--
ALTER TABLE `sitin`
  MODIFY `sit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Idno` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231231232;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
