<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "sysarc");

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch feedback for the logged-in student
if (isset($_SESSION["Idno"])) {
    $student_id = $_SESSION["Idno"];
    $sql = "SELECT * FROM feedback ORDER BY date_created DESC";
    $result = mysqli_query($con, $sql);
} else {
    echo "<script>alert('Student ID not found in session');</script>";
    exit;   
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Feedback</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        h1 {
            font-size: 24px;
            margin-bottom: 30px;
            text-align: center;
        }
        .feedback {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }
        .feedback .date {
            color: #888;
            font-size: 0.9em;
        }
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: none;
            display: inline-block;
        }

        li a {
            display: inline-block;
            color: white;
            text-align: left;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }

        .search-container {
            text-align: center;
            margin-top: 50px;
        }

        .search-container input[type=text] {
            width: 70%;
            padding: 12px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
        }

        .search-container button {
            width: 20%;
            padding: 12px;
            margin: 8px 0;
            box-sizing: border-box;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }

        .search-container button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<ul>
        <li><a href="admin.php">Admin Dashboard</a></li>
        <div class="right" style="float: right;">
            <li><a href="Sit-in.php">Sitin</a></li>
            <li><a href="View-records.php">View Sitin Records</a></li>
            <li><a href="generate-reports.php">Generate Reports</a></li>
            <li><a href="create_announcement.php">Create Announcement</a></li>
            <li><a href="view_feedback.php">View Feedbacks</a></li>
            <li><a href="Activity2.php">Log Out</a></li>
            <li>&nbsp;&nbsp;</li>
        </div>    
    </ul>
    <div class="container">
        <h1>Your Feedback</h1>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div class='feedback'>";
                echo "<p>" . htmlspecialchars($row["Idno"]) . "</p>";
                echo "<p class='date'>" . htmlspecialchars($row["date_created"]) . "</p>";
                echo "<p>" . nl2br(htmlspecialchars($row["content"])) . "</p>";
                echo "</div>";
            }
        } else {
            echo "<p>No feedback found.</p>";
        }
        mysqli_close($con);
        ?>
    </div>
</body>
</html>
