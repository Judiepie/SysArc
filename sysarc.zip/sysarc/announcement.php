<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "sysarc");

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Fetch announcements
$sql = "SELECT title, content, date_created FROM announcements ORDER BY date_created DESC";
$result = $con->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Announcements</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .announcement {
            background-color: #fff;
            margin-bottom: 20px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .announcement h2 {
            margin-top: 0;
        }
        .announcement .date {
            color: #888;
            font-size: 0.9em;
        }
        ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }

li {
float: none;
display: inline-block;
}

li a {
display: inline-block;
color: white;
text-align: left;
padding: 14px 16px;
text-decoration: none;
}

li a:hover {
background-color: #111;
}

.search-button{
    width: 100%;
    height: 50px;
    align-content: center;
}
    </style>
</head>
<body>
<ul>
    <li><a href="Student.php">Student Dashboard</a></li>
    <div class="right" style="float: right;">
            <li><a href="edit-profile.php">Edit Profile</a></li>
            <li><a href="student-history.php">History</a></li>
            <li><a href="session.php">Session</a></li>
            <li><a href="announcement.php">Announcement</a></li>
            <li><a href="Activity2.php">Log Out</a></li>
            <li>&nbsp;&nbsp;</li>
    </div>    
    </ul>
    <h1>Announcements</h1>

    <?php
    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<div class='announcement'>";
            echo "<h2>" . htmlspecialchars($row["title"]) . "</h2>";
            echo "<p class='date'>" . htmlspecialchars($row["date_created"]) . "</p>";
            echo "<p>" . nl2br(htmlspecialchars($row["content"])) . "</p>";
            echo "</div>";
        }
    } else {
        echo "<p>No announcements found.</p>";
    }
    $con->close();
    ?>
    
</body>
</html>